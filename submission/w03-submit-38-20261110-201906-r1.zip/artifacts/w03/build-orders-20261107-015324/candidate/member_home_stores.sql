SELECT
  store_id,
  region,
  store_name
FROM {{ ref('stores') }}