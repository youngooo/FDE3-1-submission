"""Large-data member8 checks using the existing independent CSV oracle.

No empty-month fixture is invented: retain its small-data evidence and add
all-covered-month grouping on large data. Default is read-only preflight.
"""
import argparse
from datetime import date, datetime
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import subprocess
import sys
import time
from zoneinfo import ZoneInfo

ROOT=Path('/home/yang/FDE/w03-work/fde-agent-w03')
sys.path.insert(0,str(ROOT/'customer/w03'))
sys.path.insert(0,str(ROOT/'platform'))
import check_member8 as member
from fde_product.metrics.common import library_digest


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text(encoding='utf-8'))
def save(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def make_cases(coverage,store):
    cases=[]
    def add(cid,family,metrics,start,end,group=None,filters=None,status='ok',reason=None):
        cases.append(dict(id=cid,family=family,expected_status=status,reason_contains=reason,
            intent=dict(metrics=metrics,start=start,end=end,group_by=group or [],filters=filters or [])))
    for suffix,start,end in [('jun','2026-06-01','2026-07-01'),('may','2026-05-01','2026-06-01'),
                             ('coverage',*coverage),('jun_first_half','2026-06-01','2026-06-16')]:
        add('first_'+suffix,'first',member.FIRST,start,end)
    for suffix,group in [('store','store'),('home_store','home_store')]:
        add('first_jun_'+suffix,'first',member.FIRST,'2026-06-01','2026-07-01',[group])
    add('first_jun_filtered_store','first',member.FIRST,'2026-06-01','2026-07-01',
        filters=[dict(field='store',op='eq',value=store)])
    add('registration_may','registration',['new_member_count'],'2026-05-01','2026-06-01')
    add('registration_coverage','registration',['new_member_count'],*coverage)
    for suffix,group in [('home_store','home_store'),('tier','member__tier')]:
        add('registration_'+suffix,'registration',['new_member_count'],*coverage,[group])
    add('monthly_jun','monthly',member.MONTHLY,'2026-06-01','2026-07-01')
    add('monthly_may','monthly',member.MONTHLY,'2026-05-01','2026-06-01')
    add('monthly_may_jun','monthly',member.MONTHLY,'2026-05-01','2026-07-01',['metric_time__month'])
    add('monthly_all_covered','monthly',member.MONTHLY,*coverage,['metric_time__month'])
    add('reject_partial_month','monthly',member.MONTHLY,'2026-06-02','2026-07-01',status='unsupported',reason='完整自然月')
    for suffix,group in [('day','metric_time__day'),('store','store')]:
        add('reject_monthly_'+suffix+'_group','monthly',member.MONTHLY,'2026-06-01','2026-07-01',
            [group],status='unsupported',reason='完整自然月')
    add('reject_monthly_store_filter','monthly',member.MONTHLY,'2026-06-01','2026-07-01',
        filters=[dict(field='store',op='eq',value=store)],status='unsupported',reason='完整自然月')
    add('reject_multimonth_total','monthly',member.MONTHLY,'2026-05-01','2026-07-01',status='unsupported',reason='按月展示')
    return cases


def prepare(args):
    manifest=read(args.data/'manifest.json');dataset=read(args.project/'dataset.json')
    if manifest['id']!='qinghe-w03-20260923-large':raise ValueError('EXPECTED_LARGE_DATASET')
    for k in ('id','coverage','counts','sha256'):
        if dataset[k]!=manifest[k]:raise ValueError('PROJECT_DATA_MISMATCH: '+k)
    for name,digest in manifest['sha256'].items():
        if sha(args.data/name)!=digest:raise ValueError('SOURCE_CHANGED: '+name)
    if not read(args.project/'validation.json').get('passed'):raise ValueError('PROJECT_NOT_VALIDATED')
    if library_digest(args.library)!=dataset['library_sha256']:raise ValueError('LIBRARY_MISMATCH')
    for path in [args.library/'metrics.yml',*args.library.glob('*.sql')]:
        if path.read_bytes()!=(args.project/'models'/path.name).read_bytes():raise ValueError('PROJECT_MODEL_CHANGED')
    if (args.library/'catalog.json').read_bytes()!=(args.project/'catalog.json').read_bytes():raise ValueError('PROJECT_CATALOG_CHANGED')
    small_path=args.project.parent/'check-member8-small/report.json'
    small=read(small_path)
    if not small.get('complete') or not small.get('passed') or small['catalog_sha256']!=dataset['library_sha256']:
        raise ValueError('SMALL_REPORT_NOT_BOUND_OR_PASSED')
    if not any(c['id']=='monthly_empty' and c['passed'] for c in small['cases']):raise ValueError('SMALL_EMPTY_MONTH_NOT_TESTED')
    oracle=member.Oracle(args.data)
    occupied={o['ordered_at'][:7] for o in oracle.valid}
    current,stop=map(date.fromisoformat,manifest['coverage']);empty=[];months=[]
    while current<stop:
        months.append(current.isoformat())
        if current.strftime('%Y-%m') not in occupied:empty.append(current.isoformat())
        current=member.next_month(current)
    if empty:raise ValueError('LARGE_DATA_HAS_EMPTY_MONTHS: re-evaluate scenario selection')
    store=sorted(oracle.stores)[0]
    cases=make_cases(manifest['coverage'],store)
    expected={c['id']:getattr(oracle,c['family'])(c['intent']) if c['expected_status']=='ok' else {} for c in cases}
    if len(cases)!=20 or len({c['id'] for c in cases})!=20:raise ValueError('CASE_IDS_INVALID')
    if set(m[0] for m in expected['monthly_all_covered'])!=set(months):raise ValueError('ORACLE_MONTHS_INCOMPLETE')
    if {m for c in cases if c['expected_status']=='ok' for m in c['intent']['metrics']}!=set(member.UNITS):
        raise ValueError('METRIC_COVERAGE_INCOMPLETE')
    for c in cases:
        if not manifest['coverage'][0]<=c['intent']['start']<c['intent']['end']<=manifest['coverage'][1]:
            raise ValueError('CASE_OUTSIDE_COVERAGE')
    tracked=[Path(__file__),Path(member.__file__),Path(member.base.__file__),Path(member.financial.__file__),
             small_path,args.project/'dataset.json',args.project/'catalog.json',args.project/'models/metrics.yml',
             *args.project.glob('models/*.sql'),args.data/'manifest.json',*args.data.glob('*.csv'),
             ROOT/'tools/w03.py',ROOT/'platform/fde_product/metrics/engine.py']
    hashes={str(p.resolve()):sha(p) for p in tracked}
    data_hash=hashlib.sha256(json.dumps({k:v for k,v in dataset.items() if k!='library_sha256'},sort_keys=True).encode()).hexdigest()
    return dataset,data_hash,cases,expected,hashes,small_path,len(months)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for arg in ('project','library','data','output'):parser.add_argument('--'+arg,type=Path,required=True)
    parser.add_argument('--run',action='store_true');args=parser.parse_args()
    for arg in ('project','library','data','output'):setattr(args,arg,getattr(args,arg).resolve())
    if args.output.exists():raise ValueError('OUTPUT_EXISTS: use new directory')
    start=time.monotonic()
    dataset,data_hash,cases,expectations,hashes,small_path,nmonths=prepare(args)
    print(f'预检通过：同一38项库；20个场景覆盖8项，全部{nmonths}个月份期望已从原始CSV独立计算。',flush=True)
    print('规模数据无空月份：空月行为保留已通过的小样本证据，规模集增加全覆盖逐月核对并改用5/6月。',flush=True)
    if not args.run:
        print('只读预检完成，未查询项目、未写入报告、未调用模型。');return 0
    args.output.mkdir(parents=True,exist_ok=False)
    save(args.output/'cases.json',cases)
    report=dict(kind='member8_large_independent_csv',project=str(args.project),library=str(args.library),
        data_version=dataset['id'],data_sha256=data_hash,catalog_sha256=dataset['library_sha256'],
        expected_basis='existing member8 Oracle from original CSV and materials03/05; no generated SQL used for expectations',
        input_sha256=hashes,small_empty_month_evidence=str(small_path),large_empty_month_case='not_applicable_no_empty_month',
        covered_month_count=nmonths,model_called=False,complete=False,passed=False,cases=[],
        started_at=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),
        environment=dict(python=sys.version,platform=platform.platform(),packages={p:importlib.metadata.version(p) for p in ['duckdb','dbt-core','dbt-metricflow']}),
        comparison_policy=dict(counts_and_cents='exact',null='strict',ratio_abs_tolerance=str(member.financial.ABS_TOL),ratio_rel_tolerance=str(member.financial.REL_TOL)))
    save(args.output/'report.json',report)
    for case in cases:
        folder=args.output/case['id'];folder.mkdir();intent=case['intent'];expected=expectations[case['id']]
        save(folder/'query.json',intent)
        save(folder/'expected.json',dict(status=case['expected_status'],groups=[dict(group=list(k),metrics=v) for k,v in sorted(expected.items())],reason_contains=case['reason_contains']))
        tick=time.monotonic();print('RUN '+case['id'],flush=True)
        try:
            run=subprocess.run([sys.executable,'-B',str(ROOT/'tools/w03.py'),'query','--project',str(args.project),
                '--input',str(folder/'query.json'),'--output',str(folder/'actual.json')],cwd=ROOT,capture_output=True,text=True,encoding='utf-8',timeout=240)
            (folder/'query.log').write_text(run.stdout+run.stderr,encoding='utf-8')
            actual=read(folder/'actual.json') if (folder/'actual.json').exists() else {}
            errors=member.compare(actual,expected,intent,case['expected_status'])
            if run.returncode:errors.append(dict(kind='process_failed',returncode=run.returncode))
            if actual.get('status')=='ok':
                for k,value in [('data_version',dataset['id']),('data_sha256',data_hash),('catalog_sha256',dataset['library_sha256'])]:
                    if actual.get(k)!=value:errors.append(dict(kind='result_version_mismatch',field=k))
            elif case['reason_contains'] and case['reason_contains'] not in actual.get('reason',''):
                errors.append(dict(kind='rejection_reason_mismatch',actual=actual.get('reason')))
        except (subprocess.TimeoutExpired,OSError,ValueError,KeyError,TypeError) as exc:
            errors=[dict(kind='execution_or_comparison_error',reason=str(exc))]
        item=dict(id=case['id'],passed=not errors,checked_metrics=intent['metrics'],errors=errors,elapsed_seconds=round(time.monotonic()-tick,3))
        save(folder/'comparison.json',item);report['cases'].append(item)
        report['elapsed_seconds']=round(time.monotonic()-start,3);save(args.output/'report.json',report)
        print(('PASS ' if item['passed'] else 'FAIL ')+case['id'],flush=True)
    report['input_changed_during_run']=[p for p,d in hashes.items() if sha(Path(p))!=d]
    report['complete']=len(report['cases'])==len(cases)
    report['passed']=report['complete'] and all(c['passed'] for c in report['cases']) and not report['input_changed_during_run']
    report['elapsed_seconds']=round(time.monotonic()-start,3);report['finished_at']=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat()
    save(args.output/'report.json',report)
    print(json.dumps(dict(passed=report['passed'],cases_passed=sum(c['passed'] for c in report['cases']),cases_total=len(cases),metrics=8,elapsed_seconds=report['elapsed_seconds'],report=str(args.output/'report.json')),ensure_ascii=False,indent=2))
    return 0 if report['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
