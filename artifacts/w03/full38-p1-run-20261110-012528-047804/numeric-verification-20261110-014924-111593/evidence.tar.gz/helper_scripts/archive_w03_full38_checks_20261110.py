"""Recompare saved numeric checks and archive evidence; no query/model calls."""
import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path
import sys
import tarfile
from zoneinfo import ZoneInfo

ROOT=Path('/home/yang/FDE/w03-work/fde-agent-w03')
RUN=ROOT/'artifacts/w03/full38-p1-run-20261110-012528-047804'
sys.path.insert(0,str(ROOT/'customer/w03'))
sys.path.insert(0,str(ROOT/'platform'))
import check_orders24 as orders
import check_member8 as members
import check_w03_paid6_csv_20261110 as paid
from fde_product.metrics.common import library_digest

SPECS=[('orders24','small',11,54.553),('member8','small',20,84.261),('paid6','small',18,86.198),
       ('orders24','large',11,60.685),('member8','large',20,95.829),('paid6','large',17,83.117)]


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text(encoding='utf-8'))


def prepare():
    library=RUN/'build';libhash=library_digest(library)
    targets={x['id'] for x in read(ROOT/'customer/w03/targets.json')}
    if len(targets)!=38 or {x['id'] for x in read(library/'catalog.json')}!=targets:
        raise ValueError('TARGET_COVERAGE_MISMATCH')
    env=read(RUN/'environment.json');build=read(RUN/'run_summary.json')
    if build['status']!='built_38_pending_independent_validation' or build['input_changed_during_build']:
        raise ValueError('BUILD_NOT_VALIDATED')
    if read(library/'validation.json').get('passed') is not True:raise ValueError('LIBRARY_NOT_VALIDATED')
    files={}
    def include(path,name=None):
        name=name or str(path.relative_to(ROOT))
        if name in files and files[name]!=path:raise ValueError('ARCHIVE_NAME_COLLISION')
        files[name]=path
    for rel,digest in env['input_sha256'].items():
        if sha(ROOT/rel)!=digest:raise ValueError('BUILD_INPUT_CHANGED: '+rel)
        include(ROOT/rel)
    checked={}
    def match(path,digest):
        if str(path) not in checked:checked[str(path)]=sha(path)
        if checked[str(path)]!=digest:raise ValueError('INPUT_CHANGED: '+str(path))
    datasets={};datahashes={}
    for size in ['small','large']:
        project=RUN/('project-'+size);dataset=read(project/'dataset.json');manifest=read(ROOT/'materials/data'/size/'manifest.json')
        if dataset['library_sha256']!=libhash or not read(project/'validation.json')['passed']:
            raise ValueError('PROJECT_NOT_BOUND: '+size)
        for k in ['id','counts','coverage','sha256']:
            if dataset[k]!=manifest[k]:raise ValueError('DATASET_MISMATCH')
        for name,digest in manifest['sha256'].items():match(ROOT/'materials/data'/size/name,digest)
        for p in [library/'metrics.yml',*library.glob('*.sql')]:
            if p.read_bytes()!=(project/'models'/p.name).read_bytes():raise ValueError('PROJECT_MODELS_CHANGED')
        if (library/'catalog.json').read_bytes()!=(project/'catalog.json').read_bytes():raise ValueError('PROJECT_CATALOG_CHANGED')
        datasets[size]=dataset
        datahashes[size]=hashlib.sha256(json.dumps({k:v for k,v in dataset.items() if k!='library_sha256'},sort_keys=True).encode()).hexdigest()
        for name in ['dataset.json','validation.json']:include(project/name)
        include(ROOT/'materials/data'/size/'manifest.json')
    summaries=[];coverage={'small':set(),'large':set()}
    for family,size,total,wall in SPECS:
        folder=RUN/f'check-{family}-{size}';report=read(folder/'report.json');dataset=datasets[size]
        if report.get('passed') is not True or report.get('complete') is not True or len(report['cases'])!=total:
            raise ValueError('INCOMPLETE_REPORT: '+folder.name)
        if report['catalog_sha256']!=libhash or report['data_version']!=dataset['id'] or Path(report['project']).resolve()!=RUN/('project-'+size):
            raise ValueError('REPORT_BINDING_MISMATCH')
        if report.get('input_changed_during_run'):raise ValueError('INPUT_CHANGED_DURING_RUN')
        for path,digest in report.get('input_sha256',{}).items():match(Path(path),digest)
        for name,digest in report.get('source_sha256',{}).items():match(ROOT/'materials/data'/size/name,digest)
        for name,digest in report.get('script_sha256',{}).items():match(ROOT/'customer/w03'/name,digest)
        if len({c['id'] for c in report['cases']})!=total:raise ValueError('DUPLICATE_CASE_ID')
        paid_cases={c['id']:c for c in read(folder/'cases.json')} if family=='paid6' else {}
        for case in report['cases']:
            sub=folder/case['id'];actual=read(sub/'actual.json');expected=read(sub/'expected.json');intent=read(sub/'query.json')
            if case['passed'] is not True or case['errors'] or read(sub/'comparison.json')!=case:
                raise ValueError('CASE_RECORD_MISMATCH')
            if family=='orders24':
                oracle={tuple(x['group']):x['metrics'] for x in expected}
                errors=orders.compare(actual,oracle,intent)
            elif family=='member8':
                oracle={tuple(x['group']):x['metrics'] for x in expected['groups']}
                errors=members.compare(actual,oracle,intent,expected['status'])
                if expected.get('reason_contains') and expected['reason_contains'] not in actual.get('reason',''):
                    errors.append({'kind':'rejection_reason_mismatch'})
            else:
                spec=paid_cases[case['id']]
                if spec['intent']!=intent or expected['status']!=spec['expected_status']:raise ValueError('PAID_CASE_CHANGED')
                errors=paid.compare(actual,expected['months'],spec,dataset,datahashes[size])
            if errors:raise ValueError('RECOMPARISON_FAILED: '+folder.name+'/'+case['id']+' '+json.dumps(errors,ensure_ascii=False))
            if actual.get('status')=='ok':
                for k,v in [('data_version',dataset['id']),('data_sha256',datahashes[size]),('catalog_sha256',libhash)]:
                    if actual.get(k)!=v:raise ValueError('ACTUAL_VERSION_MISMATCH')
                coverage[size].update(intent['metrics'])
        for p in sorted(folder.rglob('*')):
            if p.is_file():include(p)
        summaries.append(dict(suite=folder.name,cases=total,passed=total,report=str(folder/'report.json'),
            report_sha256=sha(folder/'report.json'),elapsed_seconds_recorded=report.get('elapsed_seconds'),
            terminal_wall_seconds=wall,terminal_time_source='user_pasted_terminal_output'))
    if any(ids!=targets for ids in coverage.values()):raise ValueError('PER_DATASET_METRIC_COVERAGE_INCOMPLETE')
    for name in ['environment.json','run_summary.json']:include(RUN/name)
    for p in sorted(library.iterdir()):
        if p.is_file() and p.suffix in {'.json','.yml','.sql','.md'} and p.name not in {'trace.json','response.json'}:include(p)
    for name in ['check_base16.py','check_orders24.py','check_member8.py','check_paid6_inputs.py']:
        include(ROOT/'customer/w03'/name)
    for name in ['check_w03_paid6_csv_20261110.py','check_w03_member8_large_20261110.py',Path(__file__).name]:
        include(Path(__file__).with_name(name),'helper_scripts/'+name)
    summary=dict(kind='full38_independent_numeric_verification',passed=True,small_cases=49,large_cases=48,total_cases=97,
        metric_count_per_dataset=38,library=str(library),library_sha256=libhash,suites=summaries,
        build_elapsed_seconds=build['elapsed_seconds'],environment={k:env[k] for k in ['python','platform','packages']},
        business_confirmation='pending',natural_language_regression='not_run_for_this_library',
        answer_text_review='not_run_for_this_library',final_acceptance=False,model_called=False,query_executed=False,
        replay_scope='recompare stored actual results against stored independent CSV expectations; verify source and script hashes; no query rerun',
        limitations=['规模会员无空月份、付费无零购买月份；对应边界由同库小样本覆盖',
                     '未替代自然语言问数、解释核查、课程框架改动说明或SOW整理',
                     'P1总部适用性仍待书面确认；未替换正式交付库或旧问数报告'])
    return summary,files


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--apply',action='store_true')
    args=parser.parse_args();summary,files=prepare()
    print('预检通过：六份报告绑定同一库，大小样本各覆盖38项，97个已保存结果重新判定全部通过。',flush=True)
    if not args.apply:
        print('只读预检完成，未写入归档、未查询或调用模型。');return 0
    stamp=datetime.now(ZoneInfo('Asia/Shanghai')).strftime('%Y%m%d-%H%M%S-%f')
    dest=RUN/('numeric-verification-'+stamp);dest.mkdir(exist_ok=False)
    index={name:dict(sha256=sha(path),bytes=path.stat().st_size) for name,path in files.items()}
    archive=dest/'evidence.tar.gz'
    with tarfile.open(archive,'w:gz') as tar:
        for name,path in sorted(files.items()):tar.add(path,arcname=name,recursive=False)
    with tarfile.open(archive,'r:gz') as tar:
        if set(tar.getnames())!=set(index):raise ValueError('ARCHIVE_CONTENT_MISMATCH')
        for name,info in index.items():
            if hashlib.sha256(tar.extractfile(name).read()).hexdigest()!=info['sha256']:raise ValueError('ARCHIVE_BYTES_MISMATCH')
    if any(sha(files[name])!=info['sha256'] for name,info in index.items()):raise ValueError('INPUT_CHANGED_DURING_ARCHIVE')
    summary.update(created_at=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),archive=str(archive),archive_sha256=sha(archive),archived_file_count=len(index))
    for name,obj in [('summary.json',summary),('file_index.json',index)]:
        (dest/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f'数值核对证据已归档并逐字节回读核验：{dest}',flush=True)
    print('小样本49/49，规模48/48；总部确认和本库自然语言回归仍待完成。')
    print('未修改业务模型、Skill、原始数据、指标库、原报告或聊天绑定。')
    return 0


if __name__=='__main__':raise SystemExit(main())
