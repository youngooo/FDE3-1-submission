"""Archive final merged-library regressions and reviewed answer correction evidence."""
import argparse
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
import hashlib
import json
from pathlib import Path
import tarfile
from types import SimpleNamespace
from zoneinfo import ZoneInfo
import run_w03_full38_nl_20261110 as runner

ROOT=runner.ROOT
FINAL=runner.FINAL_RUN
SPECS=[('small','full','nl-small-full-20261110-030115-607746',69),
       ('small','paid-formula','nl-small-paid-formula-20261110-031651-683666',9),
       ('large','full','nl-large-full-20261110-031957-483250',67)]
FIX=FINAL/'answer-paid-formula-fix-20261110-031428-025216'


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def tables(report):
    counts={}
    for c in report['cases']:
        if c['id'] not in {'first_home_store','paid_coverage'}:continue
        monthly=c['id']=='paid_coverage'
        expected={(str(r[0])[:7] if monthly else r[0]):r[1:] for r in c['expected']['rows']}
        seen=set()
        for line in c['actual']['answer'].splitlines():
            if not line.startswith('|'):continue
            cells=[x.strip() for x in line.strip().strip('|').split('|')]
            if not cells[0].startswith('20' if monthly else 'S'):continue
            key=cells[0]
            assert key in expected and key not in seen
            seen.add(key)
            assert len(cells[1:])==len(expected[key])
            for i,(shown,wanted) in enumerate(zip(cells[1:],expected[key])):
                if wanted is None:
                    assert shown=='未定义';continue
                actual,target=Decimal(shown),Decimal(str(wanted))
                if monthly and i>=4:
                    places=max(0,-actual.as_tuple().exponent)
                    assert abs(actual-target.quantize(Decimal(1).scaleb(-places),rounding=ROUND_HALF_UP))<=Decimal('1e-14')
                else:assert actual==target
        assert seen==set(expected)
        counts[c['id']]=len(seen)
    return counts


def prepare():
    runner.RUN=FINAL
    pointer=read(FINAL/'regression_plan.json')
    runner.PLAN=Path(pointer['plan'])
    plans={}
    protected={}
    for size in ['small','large']:
        plan,entry,_,cases,judge,hashes=runner.prepare(SimpleNamespace(dataset=size,stage='full',final_library=True))
        plans[size]=(plan,entry,{c['id']:c for c in cases},judge)
        protected.update(hashes)
    files={}
    def include(p,name=None):
        assert p.is_file(),str(p)
        name=name or str(p.relative_to(ROOT))
        assert name not in files or files[name]==p
        files[name]=p
    runs=[];reviews=[]
    original_review=read(FIX/'answer_review.json')
    for size,stage,folder,total in SPECS:
        directory=FINAL/folder
        report_path=directory/'results/metric_test_report.json'
        report,summary,env=read(report_path),read(directory/'run_summary.json'),read(directory/'environment.json')
        plan,entry,by_id,judge=plans[size]
        assert report['complete'] and report['passed']==report['total']==len(report['cases'])==total
        assert summary['official_merged_library'] and summary['library_sha256']==runner.FINAL_HASH
        assert summary['passed']==total and summary['inputs_match'] and summary['result_library_binding']
        assert summary['rejudge_consistent'] and not summary['input_changed_during_run'] and not summary['failed_cases']
        expected_ids=set(by_id) if stage=='full' else set(runner.PAID_FORMULA_CASES+['paid_zero_month'])
        assert {c['id'] for c in report['cases']}==expected_ids and len(expected_ids)==total
        metrics=set()
        for c in report['cases']:
            spec=by_id[c['id']]
            assert c['question']==spec['question'] and c['expected']==spec['expected']
            assert judge.compare(spec['expected'],c['actual'])==c['comparison']
            assert c['comparison']['passed']
            if c['actual']['status']=='ok':
                assert c['actual']['catalog_sha256']==runner.FINAL_HASH
                metrics.update(spec['expected']['intent']['metrics'])
        if stage=='full':assert len(metrics)==38
        text_hashes={c['id']:hashlib.sha256((c['actual'].get('answer') or c['actual'].get('reason') or '').encode()).hexdigest() for c in report['cases']}
        if size=='small' and stage=='full':
            assert original_review['report_sha256']==sha(report_path)
            assert original_review['answer_passed']==68 and original_review['answer_needs_fix']==1
            review={**original_review,'correction_retest_report':str(FINAL/SPECS[1][2]/'results/metric_test_report.json'),
                    'original_answer_preserved':True,'defect_closed_by_retest':True}
        else:
            assert env['input_sha256'][str(ROOT/'product/w03_answer_prompt.txt')]==runner.PAID_FORMULA_PROMPT_SHA
            for c in report['cases']:
                a=c['actual'];text=a.get('answer','').replace(' ','')
                if a['status']=='ok' and any(m.startswith('monthly_paid_') for m in a['intent']['metrics']):
                    assert 'P1' in text and '门店日期规则用于总部月报仍待书面确认' in text
                if c['id']=='paid_pair':
                    assert '月末付费会员复购人数÷月末付费会员购买人数' in text
            review=dict(kind='ai_assisted_answer_review',report=str(report_path),report_sha256=sha(report_path),
                answer_passed=total,answer_needs_fix=0,human_signoff=False,
                reviewed_scope='Assistant read every actual answer/reason, numbers, units, group labels, formulas, P1 notice, refusal and clarification.',
                cases=[dict(id=cid,status='pass',actual_text_sha256=digest) for cid,digest in text_hashes.items()])
            if size=='large':
                review['nonblocking_notes']=[
                    dict(ids=['single_cancel_rate','first_home_store','reject_outside_coverage','clarify_time'],note='部分范围表述未明确右端点不含；实际查询窗口及结论正确。'),
                    dict(ids=['orders_by_member__tier'],note='开头泛称CRM账户统计单位；随后订单定义、表头单数和金额明确正确，建议精简开头。'),
                    dict(ids=['paid_coverage'],note='开头人数范围概述较简略，应结合购买人数及复购人数列名阅读；数值和公式正确。')]
        review['display_table_rows_verified']=tables(report)
        reviews.append(review)
        runs.append(dict(dataset=size,stage=stage,report=str(report_path),report_sha256=sha(report_path),
            structured_passed=total,total=total,elapsed_seconds=summary['elapsed_seconds'],
            prompt_sha256=env['input_sha256'][str(ROOT/'product/w03_answer_prompt.txt')],
            plan=env['plan'],full_metric_coverage=len(metrics) if stage=='full' else None))
        for p in directory.rglob('*'):
            if p.is_file() and p.suffix in {'.json','.py','.txt'}:include(p)
    for folder in [Path(read(FINAL/'regression_plan.json')['plan']).parent,FINAL/'nl-cases-20261110-030006-750246']:
        for p in folder.rglob('*'):
            if p.is_file():include(p)
    include(FINAL/'regression_plan.json');include(FINAL/'summary.json')
    for p in (ROOT/'artifacts/w03/library').iterdir():
        if p.is_file():include(p)
    for size in ['small','large']:
        for name in ['dataset.json','validation.json']:include(FINAL/f'project-{size}'/name)
        include(ROOT/f'materials/data/{size}/manifest.json')
    for rel in ['product/w03_answer_prompt.txt','product/w03_intent_prompt.txt','customer/w03/judge.py',
                'customer/w03/build-metrics/SKILL.md','customer/w03/targets.json','customer/w03/build.json',
                'docs/w03/business_model.md','docs/w03/contract.md','tools/w03.py']:
        include(ROOT/rel)
    for p in (ROOT/'platform/fde_product/metrics').glob('*.py'):include(p)
    for name in ['run_w03_full38_nl_20261110.py','prepare_w03_final38_nl_20261110.py','prepare_w03_full38_nl_20261110.py',
                 'fix_w03_answer_paid_formula_20261110.py',Path(__file__).name]:
        include(Path(__file__).with_name(name),'helper_scripts/'+name)
    protected.update({str(ROOT/rel):sha(ROOT/rel) for rel in ['customer/w03/tests.json','artifacts/w03/metric_test_report.json','.runtime/product/metrics-binding.json']})
    summary=dict(kind='official_merged38_regression_evidence',library=str(ROOT/'artifacts/w03/library'),library_sha256=runner.FINAL_HASH,
        full_regressions=dict(small='69/69',large='67/67'),targeted_retest=dict(small='9/9'),runs=runs,
        original_full_execution_total=136,original_full_execution_passed=136,
        all_small_cases_executed_on_latest_prompt=False,large_full_executed_on_latest_prompt=True,
        small_answer_defect='paid_pair used ordinary monthly formula in prose; corrected prompt, 9 original cases rerun and reviewed',
        small_original_report_preserved=True,full_small_report_not_spliced=True,
        answer_review='small original 68 pass + one corrected in real retest; large all 67 reviewed with nonblocking notes',
        current_answer_prompt_sha256=runner.PAID_FORMULA_PROMPT_SHA,metric_count_per_dataset=38,
        source_expectations='Original CSV independently recomputed for final library; no observed answer used as expected value',
        model_called=False,query_executed=False,human_signoff=False,business_confirmation='pending',final_acceptance=False,
        remaining=['正式报告和用例入口尚未替换','聊天绑定尚未切换','判定器错误注入复核、框架改动说明和SOW整理尚待完成','总部P1适用性仍待书面确认'])
    return summary,reviews,files,protected


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--apply',action='store_true');args=p.parse_args()
    summary,reviews,files,protected=prepare()
    print('预检通过：正式库小样本69/69、规模67/67；修正后小样本9/9真实复测，145条保存结果重判一致。')
    print('文字核查及修复链已核对；原始报告保留，未拼接或冒充完整重跑。')
    if not args.apply:
        print('只读预检完成；未写入归档、查询或调用模型。');return
    dest=FINAL/('regression-verification-'+datetime.now(ZoneInfo('Asia/Shanghai')).strftime('%Y%m%d-%H%M%S-%f'))
    dest.mkdir(exist_ok=False)
    index={name:dict(sha256=sha(p),bytes=p.stat().st_size) for name,p in files.items()}
    archive=dest/'evidence.tar.gz'
    with tarfile.open(archive,'w:gz') as tar:
        for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
    with tarfile.open(archive,'r:gz') as tar:
        assert set(tar.getnames())==set(index)
        for name,info in index.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==info['sha256']
    assert all(sha(files[n])==i['sha256'] for n,i in index.items())
    assert all(sha(Path(p))==h for p,h in protected.items())
    assert runner.library_digest(ROOT/'artifacts/w03/library')==runner.FINAL_HASH
    summary.update(archive=str(archive),archive_sha256=sha(archive),archived_file_count=len(index))
    for name,obj in [('summary.json',summary),('answer_reviews.json',reviews),('file_index.json',index)]:
        save(dest/name,obj);assert read(dest/name)==obj
    print('正式库验证证据已归档并逐字节回读核验：'+str(dest))
    print('未修改原报告、正式用例入口、指标库、业务模型、Skill或聊天绑定；总部确认仍待完成。')


if __name__=='__main__':main()
