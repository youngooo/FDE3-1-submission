"""Archive NL execution, rejudgment and reviewed targeted retests without model calls."""
import argparse
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import tarfile
from zoneinfo import ZoneInfo
import run_w03_full38_nl_20261110 as runner

ROOT, RUN = runner.ROOT, runner.RUN
FULL = {'small': 'nl-small-full-20261110-021141-119652', 'large': 'nl-large-full-20261110-023201-558608'}
RETEST = {'small': 'nl-small-first-order-20261110-024946-733532', 'large': 'nl-large-first-order-20261110-024636-578620'}
OLD_PLAN = RUN/'nl-cases-20261110-015853-130933/plan.json'
FIX = RUN/'answer-first-order-fix-20261110-024535-189070'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def read(p):
    return json.loads(p.read_text(encoding='utf-8'))


def save(p, obj):
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def check_tables(report):
    counts = {}
    for case in report['cases']:
        if case['id'] not in {'first_home_store', 'paid_coverage'}:
            continue
        monthly = case['id'] == 'paid_coverage'
        expected = {(str(r[0])[:7] if monthly else r[0]): r[1:] for r in case['expected']['rows']}
        seen = set()
        for line in case['actual']['answer'].splitlines():
            if not line.startswith('|'):
                continue
            cells = [s.strip() for s in line.strip().strip('|').split('|')]
            key = cells[0]
            if not key.startswith('20' if monthly else 'S'):
                continue
            assert key in expected and key not in seen
            seen.add(key)
            assert len(cells[1:]) == len(expected[key])
            for i, (shown, value) in enumerate(zip(cells[1:], expected[key])):
                if value is None:
                    assert shown == '未定义'
                    continue
                actual, target = Decimal(shown), Decimal(str(value))
                if monthly and i >= 4:
                    places = max(0, -actual.as_tuple().exponent)
                    rounded = target.quantize(Decimal(1).scaleb(-places), rounding=ROUND_HALF_UP)
                    assert abs(actual-rounded) <= Decimal('1e-14'), (key, shown, value)
                else:
                    assert actual == target
        assert seen == set(expected)
        counts[case['id']] = len(seen)
    assert set(counts) == {'first_home_store', 'paid_coverage'}
    return counts


def prepare():
    files = {}
    def include(p, name=None):
        assert p.is_file(), str(p)
        name = name or str(p.relative_to(ROOT))
        assert name not in files or files[name] == p
        files[name] = p
    summaries, reviews, current_hashes = {}, {}, {}
    for size in ['small', 'large']:
        plan, entry, _, selected, judge, hashes = runner.prepare(SimpleNamespace(dataset=size, stage='first-order'))
        current_hashes.update(hashes)
        tests = read(Path(entry['cases']))
        by_id = {c['id']: c for c in tests}
        full_dir, retest_dir = RUN/FULL[size], RUN/RETEST[size]
        report_path = full_dir/'results/metric_test_report.json'
        report, run = read(report_path), read(full_dir/'run_summary.json')
        assert report['complete'] and len(report['cases']) == len(tests)
        assert {c['id'] for c in report['cases']} == set(by_id)
        assert run['complete'] and run['inputs_match'] and run['result_library_binding']
        assert run['rejudge_consistent'] and not run['input_changed_during_run']
        original_passed = 68 if size == 'small' else 67
        assert report['passed'] == run['passed'] == original_passed
        old_entry = next(e for e in read(OLD_PLAN)['entries'] if e['dataset'] == size)
        original_cases = {c['id']: c for c in read(Path(old_entry['cases']))}
        for c in report['cases']:
            current = by_id[c['id']]
            assert c['question'] == current['question']
            assert c['expected'] == (original_cases[c['id']]['expected'] if size == 'small' else current['expected'])
            assert judge.compare(current['expected'], c['actual'])['passed']
            if c['actual']['status'] == 'ok':
                assert c['actual']['catalog_sha256'] == plan['library_sha256']
        revised = read(runner.PLAN.parent/'rejudged-small-report.json')
        if size == 'small':
            assert revised['complete'] and revised['passed'] == revised['total'] == 69
            rmap = {c['id']: c for c in revised['cases']}
            assert set(rmap) == set(by_id)
            for c in report['cases']:
                assert rmap[c['id']]['actual'] == c['actual']
                assert rmap[c['id']]['expected'] == by_id[c['id']]['expected']
        focused_path = retest_dir/'results/metric_test_report.json'
        focused, focus_run = read(focused_path), read(retest_dir/'run_summary.json')
        focus_env = read(retest_dir/'environment.json')
        assert focus_run['status'] == 'structured_passed_pending_answer_review'
        assert focused['complete'] and focused['passed'] == focused['total'] == 8
        assert [c['id'] for c in focused['cases']] == runner.FIRST_ORDER_CASES
        assert not focus_run['input_changed_during_run'] and focus_run['inputs_match'] and focus_run['result_library_binding']
        assert focus_env['input_sha256'][str(ROOT/'product/w03_answer_prompt.txt')] == runner.FIRST_ORDER_PROMPT_SHA
        for c in focused['cases']:
            assert c['question'] == by_id[c['id']]['question'] and c['expected'] == by_id[c['id']]['expected']
            assert judge.compare(c['expected'], c['actual'])['passed']
            assert c['actual']['catalog_sha256'] == plan['library_sha256']
            text = c['actual']['answer']
            if c['id'] == 'single_first_order_sales_cents':
                assert '下单日期升序' in text and '同日按订单号排序' in text
            if c['id'] in {'paid_coverage', 'paid_paraphrase'}:
                assert 'P1' in text and '门店日期规则用于总部月报仍待书面确认' in text
        table_counts = check_tables(focused)
        reviews[size] = dict(kind='ai_assisted_answer_review', report=str(focused_path), report_sha256=sha(focused_path),
            reviewed_count=8, passed=8, human_signoff=False, display_table_rows_verified=table_counts,
            scope='All eight actual answers read; numeric values, units, scope, first-order chronology, P1 notice and zero/null reviewed.',
            cases=[dict(id=c['id'], status='pass', actual_text_sha256=hashlib.sha256(c['actual']['answer'].encode()).hexdigest()) for c in focused['cases']])
        summaries[size] = dict(full_report=str(report_path), full_report_sha256=sha(report_path),
            original_execution_passed=original_passed, original_execution_total=len(tests),
            rejudged_under_current_test_spec=len(tests), rejudgment_is_new_execution=False,
            full_elapsed_seconds=run['elapsed_seconds'],
            targeted_retest_report=str(focused_path), targeted_retest_sha256=sha(focused_path),
            targeted_retest_passed=8, targeted_retest_total=8, targeted_retest_elapsed_seconds=focus_run['elapsed_seconds'],
            all_full_cases_rerun_after_latest_prompt=False, answer_review='full review plus targeted correction retest',
            full_run_prompt_sha256=read(full_dir/'environment.json')['input_sha256'][str(ROOT/'product/w03_answer_prompt.txt')],
            targeted_retest_prompt_sha256=runner.FIRST_ORDER_PROMPT_SHA)
    small_review_path = Path(__file__).with_name('w03-small-full-answer-review-20261110.json')
    small_review = read(small_review_path)
    assert small_review['report_sha256'] == summaries['small']['full_report_sha256']
    large_review = read(FIX/'answer_review.json')
    assert large_review['report_sha256'] == summaries['large']['full_report_sha256']
    assert large_review['answer_needs_fix'] == 1 and large_review['issue']['id'] == 'single_first_order_sales_cents'
    current_questions = [set(c['question'] for c in read(Path(e['cases']))) for e in plan['entries']]
    assert not current_questions[0].intersection(current_questions[1])
    # Include original and revised plans, original runs, prompt backups, fixes and retests.
    for folder in RUN.iterdir():
        if folder.is_dir() and (folder.name.startswith('nl-') or folder.name.startswith('answer-')):
            for p in folder.rglob('*'):
                if p.is_file() and p.suffix in {'.json', '.py', '.txt', '.diff'}:
                    include(p)
    for p in (RUN/'build').iterdir():
        if p.is_file() and p.suffix in {'.json', '.yml', '.sql', '.md'} and p.name not in {'response.json', 'trace.json'}:
            include(p)
    for rel in ['product/w03_answer_prompt.txt', 'product/w03_intent_prompt.txt', 'customer/w03/judge.py',
                'customer/w03/targets.json', 'customer/w03/build.json', 'customer/w03/build-metrics/SKILL.md',
                'docs/w03/business_model.md', 'docs/w03/contract.md', 'tools/w03.py']:
        include(ROOT/rel)
    for p in (ROOT/'platform/fde_product/metrics').glob('*.py'):
        include(p)
    for size in ['small','large']:
        include(ROOT/f'materials/data/{size}/manifest.json')
        include(RUN/f'project-{size}/dataset.json')
        include(RUN/f'project-{size}/validation.json')
    for name in ['prepare_w03_full38_nl_20261110.py', 'run_w03_full38_nl_20261110.py', 'judge_w03_full38_20261110.py',
                 'check_w03_paid6_csv_20261110.py', 'check_w03_member8_large_20261110.py',
                 'fix_w03_answer_first_order_20261110.py', 'fix_w03_answer_p1_notice_20261110.py',
                 'w03-small-full-answer-review-20261110.json', Path(__file__).name]:
        include(Path(__file__).with_name(name), 'helper_scripts/'+name)
    for name in ['check_base16.py', 'check_orders24.py', 'check_member8.py', 'check_paid6_inputs.py']:
        include(ROOT/'customer/w03'/name)
    numeric = RUN/'numeric-verification-20261110-014924-111593'
    include(numeric/'summary.json'); include(numeric/'file_index.json')
    summary = dict(kind='full38_natural_language_evidence', library=str(RUN/'build'), library_sha256=plan['library_sha256'],
        datasets=summaries, metric_count_per_dataset=38, cross_dataset_identical_questions=0,
        original_full_execution_totals=dict(passed=135, total=136), current_spec_offline_rejudgment=dict(passed=136, total=136),
        latest_prompt_targeted_execution=dict(passed=16, total=16),
        interpretation='Full suites were run before the latest answer-prompt correction; 8 unchanged cases per dataset were rerun afterward. Offline rejudgment does not constitute new model execution.',
        numeric_archive_reference=str(numeric), numeric_checks=dict(small='49/49', large='48/48'),
        model_called=False, query_executed=False, human_signoff=False, business_confirmation='pending', final_acceptance=False,
        remaining=['总部P1适用性待书面确认', '正式交付库与聊天绑定尚未切换', '课程框架改动说明及SOW整理尚待完成'],
        answer_review='Small full 69 reviewed; large full 66 pass plus one explanation defect corrected and retested on both datasets.')
    return summary, reviews, files, current_hashes


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    summary, reviews, files, protected = prepare()
    print('预检通过：同一38项库；原始完整执行135/136，新版用例离线重判136/136；修正后真实复测16/16。')
    print('两套复测文字均8/8通过；75行展示表格核对通过；原始报告保留。')
    if not args.apply:
        print('只读预检完成；未写入归档、查询或调用模型。')
        return
    dest = RUN/('nl-verification-'+datetime.now(ZoneInfo('Asia/Shanghai')).strftime('%Y%m%d-%H%M%S-%f'))
    dest.mkdir(exist_ok=False)
    index = {name: dict(sha256=sha(p), bytes=p.stat().st_size) for name,p in files.items()}
    archive = dest/'evidence.tar.gz'
    with tarfile.open(archive, 'w:gz') as tar:
        for name,p in sorted(files.items()):
            tar.add(p, arcname=name, recursive=False)
    with tarfile.open(archive, 'r:gz') as tar:
        assert set(tar.getnames()) == set(index)
        for name, info in index.items():
            assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == info['sha256']
    assert all(sha(files[name]) == info['sha256'] for name,info in index.items())
    assert all(sha(Path(p)) == digest for p,digest in protected.items())
    summary.update(archive=str(archive), archive_sha256=sha(archive), archived_file_count=len(index), created_at=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat())
    for name,obj in [('summary.json',summary), ('answer_retest_reviews.json',reviews), ('file_index.json',index)]:
        save(dest/name,obj)
        assert read(dest/name) == obj
    print('自然语言验证证据已归档并逐字节回读核验：'+str(dest))
    print('未修改原报告、业务模型、Skill、指标库、原始数据或聊天绑定；总部确认仍待完成。')


if __name__ == '__main__':
    main()
