"""Record smoke answer review and clarify existing P1 limitations in answer prompt."""
import argparse
from datetime import datetime
import difflib
import hashlib
import json
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT=Path('/home/yang/FDE/w03-work/fde-agent-w03')
RUN=ROOT/'artifacts/w03/full38-p1-run-20261110-012528-047804'
REPORT=RUN/'nl-small-smoke-20261110-020403-776221/results/metric_test_report.json'
PROMPT=ROOT/'product/w03_answer_prompt.txt'
OLD_SHA='d29ef0eccbd8f64aa02eb5aa732669f835d9bff921429452309600e618d98b1e'
REPORT_SHA='b7a5cc79a1de7c284a488af2ca32afb8889678a5f2829f1768443126c46a453f'
RULES='''

[W03_P1_ANSWER_SCOPE_V1]
本轮definitions的constraints若明确标注“P1暂定试算”及“门店日期规则用于总部月报仍待书面确认”，成功回答必须在表格前或结尾用一句简明业务语言保留两层信息，例如：“本结果按P1暂定口径试算；门店日期规则用于总部月报仍待书面确认。”只写“P1暂定”“按现有口径”不能替代明确的总部适用性待书面确认说明。长表、多月结果、单项与多项查询均适用；无需在每一行重复。
说明来自本轮实际选中指标的definitions，不从用户问题或未选指标推断确认状态。没有上述暂定约束的普通订单或会员指标不附加P1说明；未来定义如有变化，应忠实于实际constraints。该说明只表达结果效力边界，不改变查询范围或数值，不将已成功执行的暂定试算说成不可查询，也不暗示客户已批准、正式验收或上线。
[/W03_P1_ANSWER_SCOPE_V1]
'''


def sha(raw):return hashlib.sha256(raw).hexdigest()
def save(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def prepare():
    old=PROMPT.read_bytes();report_raw=REPORT.read_bytes()
    if sha(old)!=OLD_SHA or sha(report_raw)!=REPORT_SHA:raise ValueError('INPUT_VERSION_CHANGED')
    report=json.loads(report_raw)
    if not report['complete'] or report['passed']!=8 or report['total']!=8:raise ValueError('SMOKE_REPORT_CHANGED')
    by_id={c['id']:c for c in report['cases']}
    long_answer=by_id['paid_coverage']['actual']['answer']
    if 'P1暂定试算' not in long_answer or '书面确认' in long_answer:raise ValueError('REVIEW_EVIDENCE_CHANGED')
    catalog=json.loads((RUN/'build/catalog.json').read_text())
    paid=[c for c in catalog if c['id'].startswith('monthly_paid_')]
    if len(paid)!=6 or any(not any('P1暂定试算' in s and '门店日期规则用于总部月报仍待书面确认' in s for s in c['constraints']) for c in paid):
        raise ValueError('CATALOG_P1_CONSTRAINT_CHANGED')
    notes={
        'single_valid_order_items':('pass','33件与结果一致，区分原始购买件数与净商品销量。'),
        'first_home_store':('pass','S01/S02/S03三组及四项数值一致，S03保留零值，首购使用全覆盖有效历史。'),
        'paid_coverage':('needs_wording_fix','24个月份、单位和数值一致，零分母为未定义；写了P1暂定试算，但遗漏总部适用性仍待书面确认。'),
        'paid_paraphrase':('pass','6账户、10单、47550分、4复购账户、复购率及4755分/单一致，并保留需书面确认说明。'),
        'reject_paid_group':('pass','正确说明不支持归属门店拆分，没有推荐另一种禁止分组。'),
        'reject_undefined_metric':('pass','明确净利润未定义，没有拿净销售额替代。'),
        'nonexistent_filter':('pass','说明S999999不在可查询范围，没有猜门店或返回零。'),
        'clarify_year':('pass','明确询问年份，没有从参考日期擅自补年。'),
    }
    if set(notes)!=set(by_id):raise ValueError('CASE_IDS_CHANGED')
    review=dict(kind='ai_assisted_answer_review',report=str(REPORT),report_sha256=REPORT_SHA,
        structured_passed=8,structured_total=8,answer_passed=7,answer_needs_wording_fix=1,
        reviewed_by='assistant after reading all eight actual answers/reasons and structured results',
        human_signoff=False,final_acceptance=False,business_confirmation='pending',
        cases=[dict(id=cid,status=notes[cid][0],note=notes[cid][1],
                    actual_text_sha256=sha((case['actual'].get('answer') or case['actual'].get('reason') or '').encode('utf-8')))
               for cid,case in by_id.items()],
        fix_scope='Only answer prompt: preserve existing definitions.constraints. No metric, numeric oracle, judge or historical answer edits.',
        validation='Offline source checks only; corrected generated wording must be verified in a new real run.')
    new=old+RULES.encode('utf-8')
    if '[W03_P1_ANSWER_SCOPE_V1]' in old.decode('utf-8'):raise ValueError('ALREADY_PATCHED')
    protected=[RUN/'build/catalog.json',ROOT/'customer/w03/build-metrics/SKILL.md',ROOT/'docs/w03/business_model.md',
        ROOT/'product/w03_intent_prompt.txt',ROOT/'customer/w03/judge.py',
        ROOT/'platform/fde_product/metrics/agent.py',ROOT/'platform/fde_product/metrics/engine.py',
        ROOT/'platform/fde_product/metrics/answer_display_facts.py',REPORT]
    hashes={str(p):sha(p.read_bytes()) for p in protected}
    return old,new,review,hashes


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--apply',action='store_true')
    args=parser.parse_args();old,new,review,hashes=prepare()
    print('预检通过：结构化8/8，文字7条通过、1条待补总部书面确认说明；六项目录已有该约束。',flush=True)
    print('拟更新：product/w03_answer_prompt.txt；SHA256='+sha(new),flush=True)
    if not args.apply:
        print('只读预检完成，未修改工程或调用模型。');return 0
    stamp=datetime.now(ZoneInfo('Asia/Shanghai')).strftime('%Y%m%d-%H%M%S-%f')
    dest=RUN/('answer-p1-notice-fix-'+stamp);dest.mkdir(exist_ok=False)
    (dest/'answer_prompt.before.txt').write_bytes(old);(dest/'answer_prompt.after.txt').write_bytes(new)
    (dest/'answer_prompt.diff').write_text(''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='before/product/w03_answer_prompt.txt',tofile='after/product/w03_answer_prompt.txt')),encoding='utf-8')
    save(dest/'answer_review.json',review)
    if PROMPT.read_bytes()!=old:raise ValueError('CONCURRENT_PROMPT_CHANGE')
    PROMPT.write_bytes(new)
    if PROMPT.read_bytes()!=new:raise ValueError('READBACK_MISMATCH')
    if any(sha(Path(p).read_bytes())!=h for p,h in hashes.items()):raise ValueError('PROTECTED_FILE_CHANGED')
    save(dest/'change.json',dict(status='applied',prompt_before_sha256=sha(old),prompt_after_sha256=sha(new),
        protected_sha256=hashes,model_called=False,query_executed=False,retest_required=True))
    print(f'文字核查记录、备份与差异：{dest}',flush=True)
    print('已更新回答提示；指标库、Skill、判定器、查询逻辑与历史回答未修改，无需重建指标库。')
    print('本次未调用模型；需重新运行冒烟用例核查实际回答。')
    return 0


if __name__=='__main__':raise SystemExit(main())
